INSERT INTO bugtracker.type VALUES (1,'Task');
INSERT INTO bugtracker.type VALUES (2,'Study');
INSERT INTO bugtracker.type VALUES (3,'Support');
INSERT INTO bugtracker.type VALUES (4,'Bug');