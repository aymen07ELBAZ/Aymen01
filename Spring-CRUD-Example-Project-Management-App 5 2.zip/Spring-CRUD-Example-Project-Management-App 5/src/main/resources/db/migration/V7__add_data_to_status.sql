INSERT INTO bugtracker.status VALUES (1,'To Do');
INSERT INTO bugtracker.status VALUES (2,'In Progress');
INSERT INTO bugtracker.status VALUES (3,'To Validate');
INSERT INTO bugtracker.status VALUES (4,'Done');